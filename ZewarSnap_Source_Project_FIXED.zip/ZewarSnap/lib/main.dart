import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:sqflite/sqflite.dart';

const gold = Color(0xFFD6B46A);
const bg = Color(0xFF101010);
const panel = Color(0xFF1B1B1B);
final moneyDate = DateFormat('dd MMM yyyy, hh:mm a');

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await StockDb.instance.database;
  runApp(const ZewarSnapApp());
}

class ZewarSnapApp extends StatelessWidget {
  const ZewarSnapApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'ZewarSnap',
        theme: ThemeData(
          brightness: Brightness.dark,
          scaffoldBackgroundColor: bg,
          colorScheme: const ColorScheme.dark(primary: gold, secondary: gold, surface: panel),
          appBarTheme: const AppBarTheme(backgroundColor: bg, foregroundColor: gold, centerTitle: false),
          inputDecorationTheme: InputDecorationTheme(
            filled: true, fillColor: panel,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: gold)),
            labelStyle: const TextStyle(color: Colors.white70),
          ),
          elevatedButtonTheme: ElevatedButtonThemeData(style: ElevatedButton.styleFrom(
            backgroundColor: gold, foregroundColor: Colors.black, minimumSize: const Size.fromHeight(48),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          )),
          useMaterial3: true,
        ),
        home: const HomePage(),
      );
}

class StockDb {
  StockDb._();
  static final instance = StockDb._();
  Database? _db;
  Future<Database> get database async {
    if (_db != null) return _db!;
    final dir = await getApplicationDocumentsDirectory();
    _db = await openDatabase(p.join(dir.path, 'zewarsnap.db'), version: 1,
      onCreate: (db, version) async {
        await db.execute('''CREATE TABLE items(
          id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, category TEXT NOT NULL,
          quantity REAL NOT NULL, unit TEXT NOT NULL, photo TEXT, notes TEXT,
          created_at TEXT NOT NULL, updated_at TEXT NOT NULL)''');
        await db.execute('''CREATE TABLE movements(
          id INTEGER PRIMARY KEY AUTOINCREMENT, item_id INTEGER NOT NULL,
          type TEXT NOT NULL, quantity REAL NOT NULL, unit TEXT NOT NULL,
          note TEXT, created_at TEXT NOT NULL,
          FOREIGN KEY(item_id) REFERENCES items(id) ON DELETE CASCADE)''');
      });
    return _db!;
  }

  Future<List<Map<String, Object?>>> items({String? category, String? search}) async {
    final db = await database;
    String where = '1=1'; final args = <Object?>[];
    if (category != null && category != 'All') { where += ' AND category=?'; args.add(category); }
    if (search != null && search.trim().isNotEmpty) { where += ' AND (name LIKE ? OR category LIKE ?)'; args.add('%${search.trim()}%'); args.add('%${search.trim()}%'); }
    return db.rawQuery('SELECT * FROM items WHERE $where ORDER BY updated_at DESC', args);
  }

  Future<int> addItem({required String name, required String category, required double quantity,
    required String unit, String? photo, String? notes}) async {
    final db = await database; final now = DateTime.now().toIso8601String();
    return db.transaction((txn) async {
      final id = await txn.insert('items', {'name': name, 'category': category, 'quantity': quantity,
        'unit': unit, 'photo': photo, 'notes': notes, 'created_at': now, 'updated_at': now});
      await txn.insert('movements', {'item_id': id, 'type': 'Opening Stock', 'quantity': quantity,
        'unit': unit, 'note': 'Initial stock added', 'created_at': now});
      return id;
    });
  }

  Future<void> changeStock(int id, double amount, String type, String note) async {
    final db = await database;
    await db.transaction((txn) async {
      final rows = await txn.query('items', where: 'id=?', whereArgs: [id], limit: 1);
      if (rows.isEmpty) throw Exception('Item not found');
      final current = (rows.first['quantity'] as num).toDouble();
      final unit = rows.first['unit'] as String;
      final next = type == 'Sale' || type == 'Stock Out' ? current - amount : current + amount;
      if (next < -0.000001) throw Exception('Available stock is not enough');
      final now = DateTime.now().toIso8601String();
      await txn.update('items', {'quantity': next < 0 ? 0 : next, 'updated_at': now}, where: 'id=?', whereArgs: [id]);
      await txn.insert('movements', {'item_id': id, 'type': type, 'quantity': amount, 'unit': unit,
        'note': note, 'created_at': now});
    });
  }

  Future<List<Map<String, Object?>>> history(int id) async => (await database).query('movements',
    where: 'item_id=?', whereArgs: [id], orderBy: 'created_at DESC');

  Future<void> updateItem(int id, String name, String category, String unit, String? notes, String? photo) async {
    final values = <String, Object?>{'name': name, 'category': category, 'unit': unit,
      'notes': notes, 'updated_at': DateTime.now().toIso8601String()};
    if (photo != null) values['photo'] = photo;
    await (await database).update('items', values, where: 'id=?', whereArgs: [id]);
  }

  Future<void> deleteItem(int id) async { final db = await database; await db.transaction((txn) async { await txn.delete('movements', where: 'item_id=?', whereArgs: [id]); await txn.delete('items', where: 'id=?', whereArgs: [id]); }); }

  Future<Map<String, dynamic>> exportData() async {
    final db = await database;
    return {'format': 'ZewarSnap Backup', 'version': 1,
      'items': await db.query('items'), 'movements': await db.query('movements')};
  }

  Future<void> importData(Map<String, dynamic> data) async {
    if (data['format'] != 'ZewarSnap Backup') throw Exception('یہ ZewarSnap کی بیک اپ فائل نہیں ہے');
    final db = await database;
    await db.transaction((txn) async {
      await txn.delete('movements'); await txn.delete('items');
      for (final raw in (data['items'] as List)) { await txn.insert('items', Map<String, Object?>.from(raw as Map)); }
      for (final raw in (data['movements'] as List)) { await txn.insert('movements', Map<String, Object?>.from(raw as Map)); }
    });
  }
}

const categories = ['Gold Jewellery', 'Silver Jewellery', 'Rings', 'Earrings', 'Tops', 'Bangles', 'Chains', 'Necklaces', 'Other'];
const units = ['Pieces', 'Pairs', 'Tola', 'Gram', 'Masha', 'Ratti'];
String qty(num n) => n == n.roundToDouble() ? n.toStringAsFixed(0) : n.toStringAsFixed(3).replaceAll(RegExp(r'0+$'), '').replaceAll(RegExp(r'\.$'), '');

class HomePage extends StatefulWidget { const HomePage({super.key}); @override State<HomePage> createState() => _HomePageState(); }
class _HomePageState extends State<HomePage> {
  String category = 'All'; String search = ''; bool loading = true;
  List<Map<String, Object?>> data = [];
  @override void initState() { super.initState(); refresh(); }
  Future<void> refresh() async { final rows = await StockDb.instance.items(category: category, search: search); if (!mounted) return; setState(() { data = rows; loading = false; }); }
  double get totalItems => data.length.toDouble();
  double get goldWeight => data.where((e) => e['unit'] == 'Tola').fold(0, (s, e) => s + (e['quantity'] as num).toDouble());
  Future<void> add() async { await Navigator.push(context, MaterialPageRoute(builder: (_) => const AddItemPage())); await refresh(); }
  Future<void> backup() async {
    try { final json = const JsonEncoder.withIndent('  ').convert(await StockDb.instance.exportData());
      final dir = await getTemporaryDirectory(); final file = File(p.join(dir.path, 'ZewarSnap_Backup_${DateTime.now().millisecondsSinceEpoch}.json'));
      await file.writeAsString(json); await Share.shareXFiles([XFile(file.path)], text: 'ZewarSnap stock backup');
    } catch (e) { if (mounted) _msg('Backup نہیں بن سکا: $e'); }
  }
  Future<void> restore() async {
    try { final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['json'], withData: true);
      if (result == null) return;
      final bytes = result.files.single.bytes ?? await File(result.files.single.path!).readAsBytes();
      final ok = await showDialog<bool>(context: context, builder: (c) => AlertDialog(title: const Text('Restore Backup?'),
        content: const Text('موجودہ اسٹاک اس بیک اپ سے تبدیل ہو جائے گا۔ کیا آپ جاری رکھنا چاہتے ہیں؟'),
        actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')), TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Restore'))]));
      if (ok == true) { await StockDb.instance.importData(jsonDecode(utf8.decode(bytes)) as Map<String, dynamic>); await refresh(); _msg('Backup restore ہوگیا'); }
    } catch (e) { _msg('Restore نہیں ہو سکا: $e'); }
  }
  void _msg(String s) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s))); }
  @override Widget build(BuildContext context) {
    final count = data.length;
    return Scaffold(appBar: AppBar(title: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('ZewarSnap', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.2)), Text('JEWELLERY STOCK MANAGER', style: TextStyle(fontSize: 9, letterSpacing: 2, color: Colors.white54))]),
      actions: [PopupMenuButton<String>(icon: const Icon(Icons.more_vert), onSelected: (v) => v == 'backup' ? backup() : restore(), itemBuilder: (_) => const [PopupMenuItem(value: 'backup', child: Text('Backup Stock')), PopupMenuItem(value: 'restore', child: Text('Restore Backup'))])]),
      floatingActionButton: FloatingActionButton.extended(onPressed: add, backgroundColor: gold, foregroundColor: Colors.black, icon: const Icon(Icons.add_a_photo), label: const Text('ADD STOCK')),
      body: RefreshIndicator(onRefresh: refresh, child: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 100), children: [
        Row(children: [Expanded(child: _stat('ITEMS', '$count', Icons.inventory_2_outlined)), const SizedBox(width: 10), Expanded(child: _stat('GOLD (TOLA)', qty(goldWeight), Icons.diamond_outlined))]),
        const SizedBox(height: 20), TextField(decoration: const InputDecoration(hintText: 'Search item or category...', prefixIcon: Icon(Icons.search)), onChanged: (v) { search = v; refresh(); }),
        const SizedBox(height: 14),
        SizedBox(
          height: 40,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: ['All', ...categories].map((c) {
              return Padding(
                padding: const EdgeInsets.only(right: 8),
                child: ChoiceChip(
                  label: Text(c),
                  selected: category == c,
                  selectedColor: gold,
                  labelStyle: TextStyle(
                    color: category == c ? Colors.black : Colors.white,
                  ),
                  onSelected: (_) {
                    setState(() => category = c);
                    refresh();
                  },
                ),
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 18), Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('Your Stock', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)), Text('$count items', style: const TextStyle(color: Colors.white54))]),
        const SizedBox(height: 10), if (loading) const Center(child: CircularProgressIndicator()) else if (data.isEmpty) _empty() else ...data.map((item) => _itemCard(item)),
      ])),
    );
  }
  Widget _stat(String label, String value, IconData icon) => Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16), border: Border.all(color: gold.withOpacity(.2))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, color: gold), const SizedBox(height: 12), Text(value, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold)), Text(label, style: const TextStyle(color: Colors.white54, fontSize: 10, letterSpacing: 1))]));
  Widget _empty() => Container(padding: const EdgeInsets.all(32), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16)), child: const Column(children: [Icon(Icons.photo_camera_outlined, size: 48, color: gold), SizedBox(height: 12), Text('No stock added yet', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)), Text('تصویر کے ساتھ اپنا پہلا اسٹاک شامل کریں', style: TextStyle(color: Colors.white54))]));
  Widget _itemCard(Map<String, Object?> item) {
    final photo = item['photo'] as String?; final amount = (item['quantity'] as num).toDouble();
    return Card(color: panel, margin: const EdgeInsets.only(bottom: 10), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)), child: ListTile(contentPadding: const EdgeInsets.all(10), leading: ClipRRect(borderRadius: BorderRadius.circular(10), child: photo != null && File(photo).existsSync() ? Image.file(File(photo), width: 66, height: 66, fit: BoxFit.cover) : Container(width: 66, height: 66, color: Colors.black26, child: const Icon(Icons.diamond, color: gold, size: 30))),
      title: Text(item['name'] as String, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text('${item['category']}  •  ${qty(amount)} ${item['unit']}', style: const TextStyle(color: Colors.white60)), trailing: const Icon(Icons.chevron_right, color: gold), onTap: () async { await Navigator.push(context, MaterialPageRoute(builder: (_) => ItemDetailPage(item: item))); await refresh(); }));
  }
}

class AddItemPage extends StatefulWidget { const AddItemPage({super.key}); @override State<AddItemPage> createState() => _AddItemPageState(); }
class _AddItemPageState extends State<AddItemPage> {
  final name = TextEditingController(); final quantity = TextEditingController(); final notes = TextEditingController();
  String category = categories.first, unit = 'Pieces'; String? photo; bool saving = false;
  Future<void> pick(ImageSource source) async { final x = await ImagePicker().pickImage(source: source, imageQuality: 82, maxWidth: 1600); if (x == null) return;
    final dir = await getApplicationDocumentsDirectory(); final folder = Directory(p.join(dir.path, 'stock_photos')); await folder.create(recursive: true);
    final ext = p.extension(x.path).isEmpty ? '.jpg' : p.extension(x.path); final target = p.join(folder.path, 'item_${DateTime.now().microsecondsSinceEpoch}$ext'); await File(x.path).copy(target); setState(() => photo = target); }
  Future<void> save() async { final n = name.text.trim(); final q = double.tryParse(quantity.text.trim()); if (n.isEmpty || q == null || q <= 0) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('نام اور درست مقدار درج کریں'))); return; }
    setState(() => saving = true); await StockDb.instance.addItem(name: n, category: category, quantity: q, unit: unit, photo: photo, notes: notes.text.trim()); if (mounted) Navigator.pop(context); }
  @override void dispose() { name.dispose(); quantity.dispose(); notes.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Add New Stock')), body: ListView(padding: const EdgeInsets.all(16), children: [
    GestureDetector(onTap: () => showModalBottomSheet(context: context, builder: (_) => SafeArea(child: Wrap(children: [ListTile(leading: const Icon(Icons.camera_alt), title: const Text('Take Photo'), onTap: () { Navigator.pop(context); pick(ImageSource.camera); }), ListTile(leading: const Icon(Icons.photo_library), title: const Text('Choose from Gallery'), onTap: () { Navigator.pop(context); pick(ImageSource.gallery); })]))), child: Container(height: 210, decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16), border: Border.all(color: gold.withOpacity(.4))), child: photo == null ? const Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.add_a_photo, color: gold, size: 42), SizedBox(height: 10), Text('Add Item Photo', style: TextStyle(color: gold)), Text('Camera یا Gallery', style: TextStyle(color: Colors.white54))]) : ClipRRect(borderRadius: BorderRadius.circular(16), child: Image.file(File(photo!), fit: BoxFit.cover, width: double.infinity)))),
    const SizedBox(height: 18), TextField(controller: name, textCapitalization: TextCapitalization.words, decoration: const InputDecoration(labelText: 'Item Name', hintText: 'مثلاً Gold Earrings')),
    const SizedBox(height: 14), DropdownButtonFormField<String>(value: category, decoration: const InputDecoration(labelText: 'Category'), items: categories.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => setState(() => category = v!)),
    const SizedBox(height: 14), Row(children: [Expanded(child: TextField(controller: quantity, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Quantity', hintText: 'مثلاً 2'))), const SizedBox(width: 12), Expanded(child: DropdownButtonFormField<String>(value: unit, decoration: const InputDecoration(labelText: 'Unit'), items: units.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => setState(() => unit = v!)))]),
    const SizedBox(height: 14), TextField(controller: notes, maxLines: 3, decoration: const InputDecoration(labelText: 'Notes (Optional)', hintText: 'کوئی اضافی تفصیل')),
    const SizedBox(height: 24), ElevatedButton(onPressed: saving ? null : save, child: Text(saving ? 'Saving...' : 'SAVE STOCK')),
  ]));
}

class ItemDetailPage extends StatefulWidget { final Map<String, Object?> item; const ItemDetailPage({super.key, required this.item}); @override State<ItemDetailPage> createState() => _ItemDetailPageState(); }
class _ItemDetailPageState extends State<ItemDetailPage> {
  late Map<String, Object?> item; List<Map<String, Object?>> movements = []; bool loading = true;
  @override void initState() { super.initState(); item = Map.of(widget.item); refresh(); }
  Future<void> refresh() async { final rows = await StockDb.instance.items(); final found = rows.where((e) => e['id'] == item['id']); if (found.isNotEmpty) item = Map.of(found.first); final h = await StockDb.instance.history(item['id'] as int); if (mounted) setState(() { movements = h; loading = false; }); }
  Future<void> movement(String type) async {
    final amount = TextEditingController(); final note = TextEditingController();
    final value = await showDialog<double>(context: context, builder: (c) => AlertDialog(title: Text(type == 'Sale' ? 'Record Sale' : type == 'Stock In' ? 'Add Stock' : 'Stock Out'), content: Column(mainAxisSize: MainAxisSize.min, children: [Text('Available: ${qty((item['quantity'] as num).toDouble())} ${item['unit']}'), const SizedBox(height: 12), TextField(controller: amount, autofocus: true, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(labelText: 'Quantity (${item['unit']})')), const SizedBox(height: 10), TextField(controller: note, decoration: const InputDecoration(labelText: 'Note (optional)'))]), actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('Cancel')), TextButton(onPressed: () { final v = double.tryParse(amount.text); if (v != null && v > 0) Navigator.pop(c, v); }, child: const Text('Save'))]));
    if (value == null) return;
    try { await StockDb.instance.changeStock(item['id'] as int, value, type, note.text.trim().isEmpty ? (type == 'Sale' ? 'Sold' : type) : note.text.trim()); await refresh(); }
    catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', '')))); }
  }
  Future<void> edit() async { final name = TextEditingController(text: item['name'] as String); final notes = TextEditingController(text: item['notes'] as String? ?? ''); String cat = item['category'] as String, unit = item['unit'] as String; final photo = item['photo'] as String?;
    await showDialog(context: context, builder: (c) => StatefulBuilder(builder: (c, setD) => AlertDialog(title: const Text('Edit Item'), content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [TextField(controller: name, decoration: const InputDecoration(labelText: 'Name')), const SizedBox(height: 10), DropdownButtonFormField<String>(value: cat, decoration: const InputDecoration(labelText: 'Category'), items: categories.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => setD(() => cat = v!)), const SizedBox(height: 10), DropdownButtonFormField<String>(value: unit, decoration: const InputDecoration(labelText: 'Unit'), items: units.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => setD(() => unit = v!)), const SizedBox(height: 10), TextField(controller: notes, decoration: const InputDecoration(labelText: 'Notes'))])), actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('Cancel')), TextButton(onPressed: () async { await StockDb.instance.updateItem(item['id'] as int, name.text.trim(), cat, unit, notes.text.trim(), photo); if (c.mounted) Navigator.pop(c); }, child: const Text('Save'))])));
    await refresh();
  }
  Future<void> delete() async { final yes = await showDialog<bool>(context: context, builder: (c) => AlertDialog(title: const Text('Delete Item?'), content: const Text('اس آئٹم کی ہسٹری بھی حذف ہو جائے گی۔'), actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')), TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Delete'))])); if (yes == true) { await StockDb.instance.deleteItem(item['id'] as int); if (mounted) Navigator.pop(context); } }
  @override Widget build(BuildContext context) {
    final current = (item['quantity'] as num).toDouble(); final photo = item['photo'] as String?;
    final opening = movements.where((m) => m['type'] == 'Opening Stock').fold<double>(0, (s, m) => s + (m['quantity'] as num).toDouble());
    final sold = movements.where((m) => m['type'] == 'Sale').fold<double>(0, (s, m) => s + (m['quantity'] as num).toDouble());
    return Scaffold(appBar: AppBar(title: const Text('Stock Details'), actions: [IconButton(onPressed: edit, icon: const Icon(Icons.edit)), IconButton(onPressed: delete, icon: const Icon(Icons.delete_outline))]), body: RefreshIndicator(onRefresh: refresh, child: ListView(padding: const EdgeInsets.all(16), children: [
      if (photo != null && File(photo).existsSync()) ClipRRect(borderRadius: BorderRadius.circular(16), child: Image.file(File(photo), height: 230, width: double.infinity, fit: BoxFit.cover)) else Container(height: 150, decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16)), child: const Icon(Icons.diamond, size: 60, color: gold)),
      const SizedBox(height: 16), Text(item['name'] as String, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold)), Text(item['category'] as String, style: const TextStyle(color: Colors.white54)), const SizedBox(height: 16),
      Row(children: [Expanded(child: _summary('OLD STOCK', '${qty(opening)} ${item['unit']}', Colors.white)), const SizedBox(width: 8), Expanded(child: _summary('SOLD', '${qty(sold)} ${item['unit']}', Colors.redAccent)), const SizedBox(width: 8), Expanded(child: _summary('AVAILABLE', '${qty(current)} ${item['unit']}', Colors.greenAccent))]),
      const SizedBox(height: 18), Row(children: [Expanded(child: ElevatedButton.icon(onPressed: () => movement('Sale'), icon: const Icon(Icons.point_of_sale), label: const Text('SELL'))), const SizedBox(width: 8), Expanded(child: OutlinedButton.icon(onPressed: () => movement('Stock In'), icon: const Icon(Icons.add), label: const Text('ADD STOCK')))]), const SizedBox(height: 8), OutlinedButton.icon(onPressed: () => movement('Stock Out'), icon: const Icon(Icons.remove), label: const Text('OTHER STOCK OUT')),
      const SizedBox(height: 22), const Text('STOCK HISTORY', style: TextStyle(color: gold, fontWeight: FontWeight.bold, letterSpacing: 1.2)), const SizedBox(height: 10),
      if (loading) const Center(child: CircularProgressIndicator()) else if (movements.isEmpty) const Text('No history yet', style: TextStyle(color: Colors.white54)) else ...movements.map((m) { final type = m['type'] as String; final isOut = type == 'Sale' || type == 'Stock Out'; return Container(margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.all(13), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(12)), child: Row(children: [Icon(isOut ? Icons.south_west : Icons.north_east, color: isOut ? Colors.redAccent : Colors.greenAccent), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(type, style: const TextStyle(fontWeight: FontWeight.bold)), Text(m['note'] as String? ?? '', style: const TextStyle(color: Colors.white54, fontSize: 12)), Text(moneyDate.format(DateTime.parse(m['created_at'] as String)), style: const TextStyle(color: Colors.white38, fontSize: 10))])), Text('${isOut ? '−' : '+'}${qty((m['quantity'] as num).toDouble())} ${m['unit']}', style: TextStyle(color: isOut ? Colors.redAccent : Colors.greenAccent, fontWeight: FontWeight.bold))])); }),
    ])));
  }
  Widget _summary(String label, String value, Color color) => Container(padding: const EdgeInsets.all(11), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(12)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(label, style: const TextStyle(fontSize: 9, color: Colors.white54)), const SizedBox(height: 6), Text(value, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 13))]));
}
