# ZewarSnap — Jewellery Stock Manager

A premium black-and-gold, offline-first Flutter app for keeping jewellery stock with photos and a complete stock movement history.

## Features
- Add an item with a camera photo or a photo from Gallery.
- Categories: Gold Jewellery, Silver Jewellery, Rings, Earrings, Tops, Bangles, Chains, Necklaces and Other.
- Units: Pieces, Pairs, Tola, Gram, Masha and Ratti.
- Stock detail shows opening stock, quantity sold, and current available quantity.
- Record sales, other stock-out entries, and additional stock-in entries.
- Search and category filtering.
- Edit item details; delete an item.
- JSON backup and restore.
- SQLite database and copied product photos are stored locally on the phone. No account or internet is required for normal use.

## Build an APK using only your Android phone (cloud build)

This project includes a GitHub Actions workflow at `.github/workflows/android-apk.yml`. GitHub's cloud machines compile the APK, so Flutter and Android Studio do not need to be installed on your phone.

1. On your phone, open GitHub in Chrome and sign in (create a free account if needed).
2. Create a **new public or private repository** named `zewarsnap`.
3. Upload the project files and folders into the repository root. Keep the `.github/workflows/android-apk.yml` file and its folder structure; if the GitHub mobile upload page cannot upload folders, use GitHub's browser-based Codespaces or a Git client on Android to push the extracted project.
4. Open the repository's **Actions** tab, select **Build ZewarSnap Android APK**, and tap **Run workflow**.
5. Wait for the workflow to finish with a green check mark.
6. Open that successful run, scroll to **Artifacts**, and download **ZewarSnap-Android-APK**.
7. Extract the downloaded artifact ZIP and tap `app-release.apk` to install it. Android may ask you to allow installation from that browser or file manager.

The first cloud build can take several minutes. The repository is only used to build the app; normal stock records remain stored locally on your phone.

## Local build (optional, if a computer is available later)

```bash
flutter create . --platforms=android
flutter pub get
flutter build apk --release
```

APK output: `build/app/outputs/flutter-apk/app-release.apk`.

## Important notes
- This is source code, not a prebuilt APK.
- Test camera/gallery access and backup/restore on the target phone before relying on it for business-critical stock records.
- Backup JSON currently contains item records and stock history. Product photos are stored separately in app-private storage; retain/export those photos separately if you need a full photo archive.
