package com.zewarsnap.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
